package h4;

class HochwertigeZutatenFabrik implements PizzaZutatenFabrik {

	// TO DO H2.1 & H2.2 
}
