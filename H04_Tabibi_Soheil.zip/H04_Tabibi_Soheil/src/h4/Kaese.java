package h4;


 interface Kaese {

}
