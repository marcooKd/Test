package h4;


 class IndustrielleZutatenFabrik implements PizzaZutatenFabrik {

	// TO DO H2.1 & H2.2 
	 
}
