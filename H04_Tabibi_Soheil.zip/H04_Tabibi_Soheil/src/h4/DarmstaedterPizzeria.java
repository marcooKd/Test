package h4;


class DarmstaedterPizzeria {

	// TO DO H2.1 bzw. H2.2 (Attribute korrekt erweitern)
	HochwertigeZutatenFabrik HOCHWERTIGE_ZUTATEN_FABRIK;
	IndustrielleZutatenFabrik INDUSTRIELLE_ZUTATEN_FABRIK;
	VeganeZutatenFabrik VEGANE_ZUTATEN_FABRIK;

	Pizza erstellePizza(PizzaZutatenFabrik pizzaZutatenFabrik) {
		// TO DO H2.1
		return null;
	}

	Pizza ersetzeZutat(Pizza pizza, PizzaZutatenFabrik pizzaZutatenFabrik, String zutat) {
		// TO DO H2.3
		return null;
	}

}
