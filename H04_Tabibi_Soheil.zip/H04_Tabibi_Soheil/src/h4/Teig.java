package h4;


 interface Teig {

}
