package h4;

 interface PizzaZutatenFabrik {

	// TO DO H2.1 & H2.2 
	
}
