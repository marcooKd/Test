package h4;

 interface Sosse {

}
