package h4;

class VeganeZutatenFabrik implements PizzaZutatenFabrik {

	// TO DO H2.1 & H2.2

}
