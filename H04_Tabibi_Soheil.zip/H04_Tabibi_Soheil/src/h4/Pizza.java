package h4;

class Pizza {

	Teig teig;
	Sosse sosse;

	Pizza(Teig teig, Sosse sosse) {
		setTeig(teig);
		setSosse(sosse);
	}

	void setTeig(Teig teig) {
		this.teig = teig;
	}

	void setSosse(Sosse sosse) {
		this.sosse = sosse;
	}


}
